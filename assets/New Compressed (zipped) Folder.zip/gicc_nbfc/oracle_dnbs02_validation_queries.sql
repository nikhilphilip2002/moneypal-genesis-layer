/*
DNBS02 Oracle validation queries
================================

Purpose:
Validate DNBS02 report values directly in Oracle for the period:
01-Apr-2026 to 30-Jun-2026.

Schema:
GICCPROD_NEW

Important:
These queries validate the Oracle source values we identified. Some desired
workbook values still need exact business mappings, especially GL-to-DNBS02
line mapping and sector/product mapping.
*/

/* ============================================================
   0. Period parameters
   ============================================================ */

WITH params AS (
    SELECT
        DATE '2026-04-01' AS start_date,
        DATE '2026-06-30' AS end_date
    FROM dual
)
SELECT start_date, end_date FROM params;


/* ============================================================
   1. Source table row counts for the quarter
   ============================================================ */

SELECT 'GENLNACNTS sanctioned in quarter' AS source_check,
       COUNT(*) AS row_count
FROM GICCPROD_NEW.GENLNACNTS
WHERE GNLNAC_SANC_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30'

UNION ALL
SELECT 'GENLNDISB disbursed in quarter',
       COUNT(*)
FROM GICCPROD_NEW.GENLNDISB
WHERE GENLNDISB_DISB_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30'

UNION ALL
SELECT 'LOANREPAY repayments in quarter',
       COUNT(*)
FROM GICCPROD_NEW.LOANREPAY
WHERE LNREPAY_REPAY_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30'

UNION ALL
SELECT 'ASSET_CLASSIFY_DTLS in quarter',
       COUNT(*)
FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS
WHERE ASCD_EFFECTIVE_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30'

UNION ALL
SELECT 'GLBBAL year 2026',
       COUNT(*)
FROM GICCPROD_NEW.GLBBAL
WHERE GLBBAL_YEAR = 2026;


/* ============================================================
   2. PART2 - Loans and advances from latest asset classification

   This is the raw asset-classification method used in the first
   generated DB report.
   ============================================================ */

WITH latest_asset AS (
    SELECT *
    FROM (
        SELECT
            a.*,
            ROW_NUMBER() OVER (
                PARTITION BY ASCD_ACCOUNT_NUM
                ORDER BY ASCD_EFFECTIVE_DATE DESC
            ) AS rn
        FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS a
        WHERE ASCD_EFFECTIVE_DATE <= DATE '2026-06-30'
    )
    WHERE rn = 1
)
SELECT
    COUNT(*) AS account_count,
    ROUND(SUM(ASCD_PRINC_OS) / 100000, 2) AS total_principal_os_lakhs,
    ROUND(SUM(CASE WHEN ASCD_ASSET_CAT = 'D' THEN ASCD_PRINC_OS ELSE 0 END) / 100000, 2) AS secured_os_lakhs,
    ROUND(SUM(CASE WHEN ASCD_ASSET_CAT = 'U' THEN ASCD_PRINC_OS ELSE 0 END) / 100000, 2) AS unsecured_os_lakhs
FROM latest_asset;


/* ============================================================
   3. PART2 - Loans and advances from Oracle daily loan report

   This is closer to the desired workbook than raw asset classification,
   but still may not exactly match desired PART2 unless the same business
   filters/mappings are applied.
   ============================================================ */

SELECT
    COUNT(*) AS account_count,
    ROUND(SUM(GNLNR_PRINC_OS) / 100000, 2) AS principal_os_lakhs,
    ROUND(SUM(GNLNR_DISB_AMT) / 100000, 2) AS disbursed_amount_lakhs,
    ROUND(SUM(GNLNR_TOTAL_DUE) / 100000, 2) AS total_due_lakhs,
    ROUND(SUM(NVL(GNLNR_PRINC_DUE, 0)
            + NVL(GNLNR_INT_DUE, 0)
            + NVL(GNLNR_CHG_DUE, 0)
            + NVL(GNLNR_PENAL_DUE, 0)) / 100000, 2) AS computed_due_lakhs
FROM GICCPROD_NEW.GENLN_RPT_DAY
WHERE GNLNR_REPORT_DATE = DATE '2026-06-30';


/* ============================================================
   4. PART2 - Product/scheme-wise loan outstanding

   Use this to find which products/schemes are included/excluded in
   the desired workbook.
   ============================================================ */

SELECT
    GNLNR_PROD_CODE,
    GNLNR_SCHM_CODE,
    GNLNR_SCHM_NAME,
    COUNT(*) AS account_count,
    ROUND(SUM(GNLNR_PRINC_OS) / 100000, 2) AS principal_os_lakhs,
    ROUND(SUM(GNLNR_DISB_AMT) / 100000, 2) AS disbursed_lakhs
FROM GICCPROD_NEW.GENLN_RPT_DAY
WHERE GNLNR_REPORT_DATE = DATE '2026-06-30'
GROUP BY
    GNLNR_PROD_CODE,
    GNLNR_SCHM_CODE,
    GNLNR_SCHM_NAME
ORDER BY principal_os_lakhs DESC;


/* ============================================================
   5. PART2 - Secured/unsecured proxy from asset category
   ============================================================ */

WITH latest_asset AS (
    SELECT *
    FROM (
        SELECT
            a.*,
            ROW_NUMBER() OVER (
                PARTITION BY ASCD_ACCOUNT_NUM
                ORDER BY ASCD_EFFECTIVE_DATE DESC
            ) AS rn
        FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS a
        WHERE ASCD_EFFECTIVE_DATE <= DATE '2026-06-30'
    )
    WHERE rn = 1
)
SELECT
    ASCD_ASSET_CAT,
    COUNT(*) AS account_count,
    ROUND(SUM(ASCD_PRINC_OS) / 100000, 2) AS principal_os_lakhs
FROM latest_asset
GROUP BY ASCD_ASSET_CAT
ORDER BY ASCD_ASSET_CAT;


/* ============================================================
   6. Quarter sanction, disbursement, repayment totals
   ============================================================ */

SELECT
    ROUND(SUM(GNLNAC_SANC_AMT) / 100000, 2) AS sanctioned_qtr_lakhs
FROM GICCPROD_NEW.GENLNACNTS
WHERE GNLNAC_SANC_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30';

SELECT
    ROUND(SUM(GENLNDISB_DISB_AMT) / 100000, 2) AS disbursed_qtr_lakhs
FROM GICCPROD_NEW.GENLNDISB
WHERE GENLNDISB_DISB_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30';

SELECT
    ROUND(SUM(LNREPAY_PRIN_AMT) / 100000, 2) AS principal_repaid_qtr_lakhs,
    ROUND(SUM(LNREPAY_INT_AMT) / 100000, 2) AS interest_repaid_qtr_lakhs
FROM GICCPROD_NEW.LOANREPAY
WHERE LNREPAY_REPAY_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30';


/* ============================================================
   7. PART3 - Interest income support from repayments
   ============================================================ */

SELECT
    ROUND(SUM(LNREPAY_INT_AMT) / 100000, 2) AS interest_collected_lakhs
FROM GICCPROD_NEW.LOANREPAY
WHERE LNREPAY_REPAY_DATE BETWEEN DATE '2026-04-01' AND DATE '2026-06-30';


/* ============================================================
   8. PART3 - GL based income/expense validation

   This needs official GL-to-DNBS02 mapping for final classification.
   The query below groups by GL description so the finance team can map.
   ============================================================ */

SELECT
    b.GLBBAL_GLACC_CODE,
    g.EXTGL_EXT_HEAD_DESCN,
    g.EXTGL_CONC_DESCN,
    g.EXTGL_INT_INCOME,
    g.EXTGL_INVSTMT_INCOME,
    g.EXTGL_INT_EXPENSES,
    g.EXTGL_OPERATIONAL_EXPS,
    g.EXTGL_DEPCRECIATION_COSTS,
    ROUND(SUM(b.GLBBAL_BC_BAL) / 100000, 2) AS balance_lakhs
FROM GICCPROD_NEW.GLBBAL b
LEFT JOIN GICCPROD_NEW.EXTGL g
    ON TO_CHAR(g.EXTGL_GL_HEAD) = b.GLBBAL_GLACC_CODE
WHERE b.GLBBAL_YEAR = 2026
GROUP BY
    b.GLBBAL_GLACC_CODE,
    g.EXTGL_EXT_HEAD_DESCN,
    g.EXTGL_CONC_DESCN,
    g.EXTGL_INT_INCOME,
    g.EXTGL_INVSTMT_INCOME,
    g.EXTGL_INT_EXPENSES,
    g.EXTGL_OPERATIONAL_EXPS,
    g.EXTGL_DEPCRECIATION_COSTS
ORDER BY ABS(SUM(b.GLBBAL_BC_BAL)) DESC;


/* ============================================================
   9. PART1/PART2 - GL keyword validation

   These are not final RBI mappings. They are validation helpers only.
   ============================================================ */

SELECT
    CASE
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%EQUITY SHARES%' THEN 'Equity Shares'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SHARES PREMIUM%' THEN 'Share Premium'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SPECIAL RESERVE%' THEN 'Special Reserve'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%GENERAL RESERVE%' THEN 'General Reserve'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BANK%' AND UPPER(g.EXTGL_EXT_HEAD_DESCN) NOT LIKE '%OD%' THEN 'Bank Balance/Deposit'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%OD%' THEN 'Bank OD'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%INVESTMENT%' THEN 'Investment'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%COMPUTER%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%MOTOR%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SOFTWARE%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%FURNITURE%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BUILDING%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%PLANT%' THEN 'Fixed Asset'
        ELSE 'Other'
    END AS dnbs_proxy_bucket,
    ROUND(SUM(ABS(b.GLBBAL_BC_BAL)) / 100000, 2) AS amount_lakhs
FROM GICCPROD_NEW.GLBBAL b
LEFT JOIN GICCPROD_NEW.EXTGL g
    ON TO_CHAR(g.EXTGL_GL_HEAD) = b.GLBBAL_GLACC_CODE
WHERE b.GLBBAL_YEAR = 2026
GROUP BY
    CASE
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%EQUITY SHARES%' THEN 'Equity Shares'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SHARES PREMIUM%' THEN 'Share Premium'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SPECIAL RESERVE%' THEN 'Special Reserve'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%GENERAL RESERVE%' THEN 'General Reserve'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BANK%' AND UPPER(g.EXTGL_EXT_HEAD_DESCN) NOT LIKE '%OD%' THEN 'Bank Balance/Deposit'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%OD%' THEN 'Bank OD'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%INVESTMENT%' THEN 'Investment'
        WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%COMPUTER%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%MOTOR%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SOFTWARE%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%FURNITURE%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BUILDING%'
          OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%PLANT%' THEN 'Fixed Asset'
        ELSE 'Other'
    END
ORDER BY dnbs_proxy_bucket;


/* ============================================================
   10. PART8C - Asset classification summary from GENLN_RPT_DAY
   ============================================================ */

SELECT
    GNLNR_ASSET_CD,
    COUNT(*) AS account_count,
    ROUND(SUM(GNLNR_PRINC_OS) / 100000, 2) AS principal_os_lakhs,
    ROUND(SUM(NVL(GNLNR_PROVISION_AMT, 0)) / 100000, 2) AS provision_lakhs
FROM GICCPROD_NEW.GENLN_RPT_DAY
WHERE GNLNR_REPORT_DATE = DATE '2026-06-30'
GROUP BY GNLNR_ASSET_CD
ORDER BY GNLNR_ASSET_CD;


/* ============================================================
   11. PART8C - Asset classification summary from raw asset table
   ============================================================ */

WITH latest_asset AS (
    SELECT *
    FROM (
        SELECT
            a.*,
            ROW_NUMBER() OVER (
                PARTITION BY ASCD_ACCOUNT_NUM
                ORDER BY ASCD_EFFECTIVE_DATE DESC
            ) AS rn
        FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS a
        WHERE ASCD_EFFECTIVE_DATE <= DATE '2026-06-30'
    )
    WHERE rn = 1
)
SELECT
    ASCD_ASSET_CODE,
    COUNT(*) AS account_count,
    ROUND(SUM(ASCD_PRINC_OS) / 100000, 2) AS principal_os_lakhs,
    ROUND(SUM(NVL(ASCD_PRINC_DUE, 0)
            + NVL(ASCD_INT_DUE, 0)
            + NVL(ASCD_CHARG_DUE, 0)
            + NVL(ASCD_PENAL_DUE, 0)) / 100000, 2) AS due_lakhs
FROM latest_asset
GROUP BY ASCD_ASSET_CODE
ORDER BY ASCD_ASSET_CODE;


/* ============================================================
   12. Annex9 - Top 25 borrowers from GENLN_RPT_DAY

   This is likely closer to the desired Annex9 because it includes PAN,
   customer name, asset code, outstanding, interest outstanding/due, etc.
   ============================================================ */

SELECT *
FROM (
    SELECT
        ROW_NUMBER() OVER (
            ORDER BY
                NVL(GNLNR_PRINC_OS, 0)
              + NVL(GNLNR_INT_OS, 0)
              + NVL(GNLNR_INT_DUE, 0)
              + NVL(GNLNR_CHG_DUE, 0)
              + NVL(GNLNR_PENAL_DUE, 0) DESC
        ) AS sr_no,
        GNLNR_CUST_NAME AS borrower_name,
        NVL(GNLNR_PAN_NO, 'NA') AS pan,
        CASE
            WHEN GNLNR_CUST_NAME IS NULL THEN 'NA'
            ELSE 'INDIVIDUAL'
        END AS borrower_type_placeholder,
        ROUND(NVL(GNLNR_SANCTION_AMT, GNLNR_DISB_AMT) / 100000, 2) AS sanctioned_lakhs,
        ROUND(NVL(GNLNR_DISB_AMT, 0) / 100000, 2) AS disbursed_lakhs,
        ROUND((NVL(GNLNR_SANCTION_AMT, GNLNR_DISB_AMT) - NVL(GNLNR_DISB_AMT, 0)) / 100000, 2) AS undisbursed_lakhs,
        ROUND(NVL(GNLNR_PRINC_OS, 0) / 100000, 2) AS principal_os_lakhs,
        ROUND((NVL(GNLNR_INT_OS, 0) + NVL(GNLNR_INT_DUE, 0)) / 100000, 2) AS interest_os_lakhs,
        CASE
            WHEN GNLNR_ASSET_CD IN ('STD', 'SMA0', 'SMA1', 'SMA2') THEN 'Standard'
            ELSE GNLNR_ASSET_CD
        END AS status_of_account,
        ROUND((NVL(GNLNR_PRINC_OS, 0)
             + NVL(GNLNR_INT_OS, 0)
             + NVL(GNLNR_INT_DUE, 0)
             + NVL(GNLNR_CHG_DUE, 0)
             + NVL(GNLNR_PENAL_DUE, 0)) / 100000, 2) AS amount_outstanding_lakhs,
        GNLNR_ACNT_NUM,
        GNLNR_SCHM_CODE,
        GNLNR_SCHM_NAME
    FROM GICCPROD_NEW.GENLN_RPT_DAY
    WHERE GNLNR_REPORT_DATE = DATE '2026-06-30'
)
WHERE sr_no <= 25
ORDER BY sr_no;


/* ============================================================
   13. Annex9 - Top 25 borrowers aggregated by customer/PAN

   Run this if the desired report consolidates multiple accounts for
   the same borrower.
   ============================================================ */

SELECT *
FROM (
    SELECT
        ROW_NUMBER() OVER (
            ORDER BY SUM(NVL(GNLNR_PRINC_OS, 0)
                       + NVL(GNLNR_INT_OS, 0)
                       + NVL(GNLNR_INT_DUE, 0)
                       + NVL(GNLNR_CHG_DUE, 0)
                       + NVL(GNLNR_PENAL_DUE, 0)) DESC
        ) AS sr_no,
        GNLNR_CUST_NAME AS borrower_name,
        NVL(GNLNR_PAN_NO, 'NA') AS pan,
        ROUND(SUM(NVL(GNLNR_SANCTION_AMT, GNLNR_DISB_AMT)) / 100000, 2) AS sanctioned_lakhs,
        ROUND(SUM(NVL(GNLNR_DISB_AMT, 0)) / 100000, 2) AS disbursed_lakhs,
        ROUND(SUM(NVL(GNLNR_PRINC_OS, 0)) / 100000, 2) AS principal_os_lakhs,
        ROUND(SUM(NVL(GNLNR_INT_OS, 0) + NVL(GNLNR_INT_DUE, 0)) / 100000, 2) AS interest_os_lakhs,
        ROUND(SUM(NVL(GNLNR_PRINC_OS, 0)
                + NVL(GNLNR_INT_OS, 0)
                + NVL(GNLNR_INT_DUE, 0)
                + NVL(GNLNR_CHG_DUE, 0)
                + NVL(GNLNR_PENAL_DUE, 0)) / 100000, 2) AS amount_outstanding_lakhs
    FROM GICCPROD_NEW.GENLN_RPT_DAY
    WHERE GNLNR_REPORT_DATE = DATE '2026-06-30'
    GROUP BY GNLNR_CUST_NAME, NVL(GNLNR_PAN_NO, 'NA')
)
WHERE sr_no <= 25
ORDER BY sr_no;


/* ============================================================
   14. PART8 - Sector/product/purpose analysis base

   This does not complete PART8 by itself. It gives the base grouping
   needed to map products/schemes/purposes to RBI sectors.
   ============================================================ */

SELECT
    GNLNR_PROD_CODE,
    GNLNR_SCHM_CODE,
    GNLNR_SCHM_NAME,
    GNLNR_PURPOSE_CODE,
    GNLNR_PURPOSE_NAME,
    COUNT(*) AS account_count,
    ROUND(SUM(GNLNR_PRINC_OS) / 100000, 2) AS principal_os_lakhs,
    ROUND(SUM(NVL(GNLNR_PROVISION_AMT, 0)) / 100000, 2) AS provision_lakhs
FROM GICCPROD_NEW.GENLN_RPT_DAY
WHERE GNLNR_REPORT_DATE = DATE '2026-06-30'
GROUP BY
    GNLNR_PROD_CODE,
    GNLNR_SCHM_CODE,
    GNLNR_SCHM_NAME,
    GNLNR_PURPOSE_CODE,
    GNLNR_PURPOSE_NAME
ORDER BY principal_os_lakhs DESC;


/* ============================================================
   15. Annex10 - Investment candidate GL details

   Use this when no dedicated investment detail table is confirmed.
   Desired Annex10 has investment entity-level rows, so a proper
   investment detail table/mapping is still required.
   ============================================================ */

SELECT
    b.GLBBAL_GLACC_CODE,
    g.EXTGL_EXT_HEAD_DESCN,
    g.EXTGL_CONC_DESCN,
    ROUND(SUM(b.GLBBAL_BC_BAL) / 100000, 2) AS balance_lakhs
FROM GICCPROD_NEW.GLBBAL b
LEFT JOIN GICCPROD_NEW.EXTGL g
    ON TO_CHAR(g.EXTGL_GL_HEAD) = b.GLBBAL_GLACC_CODE
WHERE b.GLBBAL_YEAR = 2026
  AND (
        UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%INVEST%'
     OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SHARE%'
     OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%MUTUAL%'
     OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%DEBENTURE%'
  )
GROUP BY
    b.GLBBAL_GLACC_CODE,
    g.EXTGL_EXT_HEAD_DESCN,
    g.EXTGL_CONC_DESCN
ORDER BY ABS(SUM(b.GLBBAL_BC_BAL)) DESC;


/* ============================================================
   16. Shareholding candidate tables
   ============================================================ */

SELECT *
FROM GICCPROD_NEW.MIG_SHARE_DETAILS
FETCH FIRST 50 ROWS ONLY;

SELECT *
FROM GICCPROD_NEW.SHARE_FOLIO_MAIN_BK
FETCH FIRST 50 ROWS ONLY;


/* ============================================================
   17. NCD/debenture candidate tables
   ============================================================ */

SELECT *
FROM GICCPROD_NEW.NCDAPPL
FETCH FIRST 50 ROWS ONLY;

SELECT *
FROM GICCPROD_NEW.NCDAPPL_STATUS
FETCH FIRST 50 ROWS ONLY;

SELECT *
FROM GICCPROD_NEW.MIG_NCD_DEPACNTS
FETCH FIRST 50 ROWS ONLY;


/* ============================================================
   18. Branch candidate tables
   ============================================================ */

SELECT *
FROM GICCPROD_NEW.MIG_B_GEN_BRANCHDETAILS_P_TBL_
FETCH FIRST 50 ROWS ONLY;

SELECT *
FROM GICCPROD_NEW.MIG_AC_BRANCH_BK
FETCH FIRST 50 ROWS ONLY;

SELECT *
FROM GICCPROD_NEW.BRANCH_MERGE_V2
FETCH FIRST 50 ROWS ONLY;


/* ============================================================
   19. Find possible DNBS/RBI/report mapping tables
   ============================================================ */

SELECT
    owner,
    table_name,
    num_rows
FROM all_tables
WHERE owner = 'GICCPROD_NEW'
  AND (
        UPPER(table_name) LIKE '%DNBS%'
     OR UPPER(table_name) LIKE '%RBI%'
     OR UPPER(table_name) LIKE '%REPORT%'
     OR UPPER(table_name) LIKE '%MAPPING%'
     OR UPPER(table_name) LIKE '%MAP%'
  )
ORDER BY table_name;


/* ============================================================
   20. Find possible investment detail tables
   ============================================================ */

SELECT
    owner,
    table_name,
    num_rows
FROM all_tables
WHERE owner = 'GICCPROD_NEW'
  AND (
        UPPER(table_name) LIKE '%INVEST%'
     OR UPPER(table_name) LIKE '%MUTUAL%'
     OR UPPER(table_name) LIKE '%SHARE%'
     OR UPPER(table_name) LIKE '%SECURITY%'
     OR UPPER(table_name) LIKE '%PORTFOLIO%'
  )
ORDER BY table_name;

