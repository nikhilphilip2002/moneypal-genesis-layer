# DNBS02 Postgres Report Builder

This repo builds the DNBS02 Excel report from Postgres bronze-schema tables for the period `2026-04-01` to `2026-06-30`.

## 1. Add DB Credentials

Create `.env` or fill `db_info.txt` using this format:

```text
PGHOST=localhost
PGPORT=5432
PGDATABASE=your_database
PGUSER=your_user
PGPASSWORD=your_password
PGSCHEMA=bronze
```

`DATABASE_URL=postgresql://user:password@host:5432/database` is also supported.

## 2. Install Dependencies

```powershell
pip install -r requirements.txt
```

## 3. Extract Template Structure

Already generated at `config/dnbs02_template_spec.json` from:

```powershell
python scripts/extract_dnbs02_template.py --template "C:\Users\ADMIN\Downloads\DNBS02_Report_20260630_20260723_150900.xlsx" --out config/dnbs02_template_spec.json
```

## 4. Discover Correct Bronze Tables

```powershell
python scripts/discover_bronze_schema.py --start-date 2026-04-01 --end-date 2026-06-30 --out outputs/bronze_discovery.json
```

Open `outputs/bronze_discovery.json` and check:

- `tables`: all bronze tables, columns, row counts, date columns, numeric columns.
- `rows_in_period_by_date_column`: which date column actually contains rows between `2026-04-01` and `2026-06-30`.
- `report_candidates`: ranked table candidates for sources of funds, application of funds, P&L, asset classification, top borrowers, investments, and branches.

## 5. Fill Mapping

Update `config/dnbs02_mapping.json`.

- `scalar_cells` writes one SQL result to one Excel cell.
- `tables` writes query results into report ranges while preserving workbook formatting.
- Use `%(start_date)s` and `%(end_date)s` in SQL.

## 6. Generate Report

```powershell
python scripts/generate_dnbs02_report.py --template "C:\Users\ADMIN\Downloads\DNBS02_Report_20260630_20260723_150900.xlsx" --mapping config/dnbs02_mapping.json --start-date 2026-04-01 --end-date 2026-06-30 --out-dir outputs
```

The generated workbook is saved under `outputs/`.
