from __future__ import annotations

import os
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None


def _read_key_value_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values

    oracle_seen = False
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip().upper()
        value = value.split("#", 1)[0].strip().rstrip(",").strip('"').strip("'")

        if key == "SERVICE_NAME":
            oracle_seen = True
            values["ORACLE_SERVICE_NAME"] = value
        elif key in {"HOST", "PORT", "USER", "PASSWORD"}:
            target = f"ORACLE_{key}"
            if oracle_seen or key not in values:
                values[target] = value
        elif key.startswith("ORACLE_"):
            values[key] = value

    return values


def load_oracle_env() -> None:
    if load_dotenv:
        load_dotenv()
    for key, value in _read_key_value_file(Path("db_info.txt")).items():
        os.environ[key] = value


def connect() -> Any:
    load_oracle_env()
    try:
        import oracledb
    except ImportError as exc:
        raise SystemExit(
            "Missing Oracle driver. Install dependencies with: pip install -r requirements.txt"
        ) from exc

    required = [
        "ORACLE_HOST",
        "ORACLE_PORT",
        "ORACLE_SERVICE_NAME",
        "ORACLE_USER",
        "ORACLE_PASSWORD",
    ]
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        raise SystemExit(
            "Missing Oracle credentials: "
            + ", ".join(missing)
            + ". Put them in db_info.txt or .env."
        )

    dsn = oracledb.makedsn(
        os.environ["ORACLE_HOST"],
        int(os.environ["ORACLE_PORT"]),
        service_name=os.environ["ORACLE_SERVICE_NAME"],
    )
    return oracledb.connect(
        user=os.environ["ORACLE_USER"],
        password=os.environ["ORACLE_PASSWORD"],
        dsn=dsn,
    )
