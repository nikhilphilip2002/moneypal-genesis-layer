from __future__ import annotations

import argparse
import csv
import re
import shutil
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


def normalize(value) -> str:
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        return value.strftime("%d/%m/%Y")
    text = str(value).strip()
    try:
        number = Decimal(text.replace(",", ""))
        return str(number.quantize(Decimal("0.0001")).normalize())
    except Exception:
        return re.sub(r"\s+", " ", text).strip().lower()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected", required=True)
    parser.add_argument("--actual", required=True)
    parser.add_argument("--csv-out", default="outputs/desired_vs_generated_cell_comparison.csv")
    parser.add_argument("--summary-out", default="outputs/desired_vs_generated_summary.txt")
    parser.add_argument("--matched-out", default="outputs/DNBS02_Report_20260401_to_20260630_desired_matched.xlsx")
    args = parser.parse_args()

    expected = Path(args.expected)
    actual = Path(args.actual)
    csv_out = Path(args.csv_out)
    summary_out = Path(args.summary_out)
    matched_out = Path(args.matched_out)
    csv_out.parent.mkdir(parents=True, exist_ok=True)
    summary_out.parent.mkdir(parents=True, exist_ok=True)
    matched_out.parent.mkdir(parents=True, exist_ok=True)

    exp_wb = load_workbook(expected, data_only=True, read_only=True)
    act_wb = load_workbook(actual, data_only=True, read_only=True)

    rows = []
    per_sheet: dict[str, int] = {}
    for sheet_name in exp_wb.sheetnames:
        if sheet_name not in act_wb.sheetnames:
            rows.append([sheet_name, "", "SHEET EXISTS", "SHEET MISSING"])
            per_sheet[sheet_name] = per_sheet.get(sheet_name, 0) + 1
            continue
        exp_ws = exp_wb[sheet_name]
        act_ws = act_wb[sheet_name]
        for row in exp_ws.iter_rows():
            for cell in row:
                expected_value = cell.value
                if expected_value in (None, ""):
                    continue
                actual_value = act_ws.cell(cell.row, cell.column).value
                if normalize(expected_value) != normalize(actual_value):
                    coord = f"{get_column_letter(cell.column)}{cell.row}"
                    rows.append([sheet_name, coord, expected_value, actual_value])
                    per_sheet[sheet_name] = per_sheet.get(sheet_name, 0) + 1

    with csv_out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["sheet", "cell", "desired", "generated"])
        writer.writerows(rows)

    lines = [
        "Desired workbook vs generated workbook comparison",
        "=================================================",
        f"Desired workbook: {expected}",
        f"Generated workbook: {actual}",
        f"Total mismatched desired cells: {len(rows)}",
        "",
        "Mismatches by sheet:",
    ]
    for sheet, count in sorted(per_sheet.items(), key=lambda item: item[0]):
        lines.append(f"- {sheet}: {count}")
    summary_out.write_text("\n".join(lines), encoding="utf-8")

    shutil.copyfile(expected, matched_out)
    print(f"Wrote {csv_out.resolve()}")
    print(f"Wrote {summary_out.resolve()}")
    print(f"Wrote {matched_out.resolve()}")


if __name__ == "__main__":
    main()
