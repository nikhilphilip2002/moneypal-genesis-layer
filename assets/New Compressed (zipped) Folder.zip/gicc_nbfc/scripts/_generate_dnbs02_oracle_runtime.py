from __future__ import annotations

import argparse
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from oracle_db import connect


LAKH = Decimal("100000")


def as_lakh(value: Any) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(value) / LAKH


def cell(ws, ref: str, value: Any) -> None:
    ws[ref] = value


def q1(cur, sql: str, params: dict[str, Any] | None = None) -> Any:
    cur.execute(sql, {key: value for key, value in (params or {}).items() if key in sql})
    row = cur.fetchone()
    return None if row is None else row[0]


def rows(cur, sql: str, params: dict[str, Any] | None = None) -> list[tuple]:
    cur.execute(sql, {key: value for key, value in (params or {}).items() if key in sql})
    return cur.fetchall()


def clear_range(ws, min_row: int, max_row: int, min_col: int, max_col: int) -> None:
    for row in range(min_row, max_row + 1):
        for col in range(min_col, max_col + 1):
            ws.cell(row, col).value = None


def write_rows(ws, start_row: int, start_col: int, data: list[tuple], max_rows: int) -> None:
    clear_range(ws, start_row, start_row + max_rows - 1, start_col, start_col + (len(data[0]) if data else 1) - 1)
    for r_idx, row in enumerate(data[:max_rows], start_row):
        for c_idx, value in enumerate(row, start_col):
            ws.cell(r_idx, c_idx).value = value


def latest_asset_cte() -> str:
    return """
    with latest_asset as (
      select
        ascd_account_num,
        ascd_asset_cat,
        ascd_asset_code,
        ascd_dpd_days,
        ascd_princ_os,
        ascd_princ_due,
        ascd_int_due,
        ascd_charg_due,
        ascd_effective_date
      from (
        select a.*,
          row_number() over (partition by ascd_account_num order by ascd_effective_date desc) rn
        from GICCPROD_NEW.asset_classify_dtls a
        where ascd_effective_date <= :end_date
      )
      where rn = 1
    )
    """


def gl_sum(cur, include: list[str], exclude: list[str] | None = None) -> Decimal:
    clauses = ["glbbal_year = 2026"]
    params: dict[str, Any] = {}
    inc = []
    for idx, token in enumerate(include):
        key = f"inc{idx}"
        inc.append(f"upper(coalesce(extgl_ext_head_descn, '')) like upper(:{key})")
        params[key] = f"%{token}%"
    clauses.append("(" + " or ".join(inc) + ")")
    for idx, token in enumerate(exclude or []):
        key = f"exc{idx}"
        clauses.append(f"upper(coalesce(extgl_ext_head_descn, '')) not like upper(:{key})")
        params[key] = f"%{token}%"
    sql = f"""
      select coalesce(sum(abs(glbbal_bc_bal)), 0)
      from GICCPROD_NEW.glbbal b
      left join GICCPROD_NEW.extgl g on to_char(g.extgl_gl_head) = b.glbbal_glacc_code
      where {' and '.join(clauses)}
    """
    return as_lakh(q1(cur, sql, params))


def fill_filing(wb, start_date: str, end_date: str) -> None:
    ws = wb["FilingInfo"]
    cell(ws, "C12", start_date)
    cell(ws, "C13", end_date)
    cell(ws, "C14", "INR")
    cell(ws, "C15", "LAKHS")
    cell(ws, "C19", "Draft generated from bronze schema")


def fill_loan_sections(wb, cur, params: dict[str, Any]) -> dict[str, Any]:
    metrics: dict[str, Any] = {}
    loan_outstanding = as_lakh(q1(cur, latest_asset_cte() + "select sum(ascd_princ_os) from latest_asset", params))
    secured_os = as_lakh(q1(cur, latest_asset_cte() + "select sum(ascd_princ_os) from latest_asset where ascd_asset_cat = 'D'", params))
    unsecured_os = as_lakh(q1(cur, latest_asset_cte() + "select sum(ascd_princ_os) from latest_asset where ascd_asset_cat = 'U'", params))
    sanctioned = as_lakh(q1(cur, "select sum(gnlnac_sanc_amt) from GICCPROD_NEW.genlnacnts where gnlnac_sanc_date between :start_date and :end_date", params))
    disbursed = as_lakh(q1(cur, "select sum(genlndisb_disb_amt) from GICCPROD_NEW.genlndisb where genlndisb_disb_date between :start_date and :end_date", params))
    principal_repaid = as_lakh(q1(cur, "select sum(lnrepay_prin_amt) from GICCPROD_NEW.loanrepay where lnrepay_repay_date between :start_date and :end_date", params))
    interest_repaid = as_lakh(q1(cur, "select sum(lnrepay_int_amt) from GICCPROD_NEW.loanrepay where lnrepay_repay_date between :start_date and :end_date", params))

    metrics.update(
        {
            "loan_outstanding_lakhs": loan_outstanding,
            "secured_outstanding_lakhs": secured_os,
            "unsecured_outstanding_lakhs": unsecured_os,
            "sanctioned_qtr_lakhs": sanctioned,
            "disbursed_qtr_lakhs": disbursed,
            "principal_repaid_qtr_lakhs": principal_repaid,
            "interest_repaid_qtr_lakhs": interest_repaid,
        }
    )

    ws = wb["DNBS02_PART2"]
    cell(ws, "C13", loan_outstanding)
    cell(ws, "C14", secured_os)
    cell(ws, "C15", unsecured_os)
    cell(ws, "C67", loan_outstanding)
    cell(ws, "C69", loan_outstanding)

    ws = wb["DNBS02_PART3"]
    cell(ws, "C20", interest_repaid)
    cell(ws, "C22", interest_repaid)
    cell(ws, "C32", interest_repaid)
    cell(ws, "C36", Decimal("0"))
    cell(ws, "C52", Decimal("0"))
    cell(ws, "C53", interest_repaid)

    ws = wb["DNBS02_PART8"]
    total_accounts = q1(cur, latest_asset_cte() + "select count(*) from latest_asset", params)
    std_accounts = q1(cur, latest_asset_cte() + "select count(*) from latest_asset where ascd_asset_code in ('STD', 'SMA0')", params)
    std_os = as_lakh(q1(cur, latest_asset_cte() + "select sum(ascd_princ_os) from latest_asset where ascd_asset_code in ('STD', 'SMA0')", params))
    for row in [13, 14, 16]:
        cell(ws, f"C{row}", total_accounts)
        cell(ws, f"D{row}", loan_outstanding)
        cell(ws, f"S{row}", std_accounts)
        cell(ws, f"T{row}", std_os)

    ws = wb["DNBS02_PART8C"]
    class_rows = rows(
        cur,
        latest_asset_cte()
        + """
        select ascd_asset_code, count(*), sum(ascd_princ_os), sum(ascd_princ_due + ascd_int_due + ascd_charg_due)
        from latest_asset
        group by ascd_asset_code
        order by ascd_asset_code
        """,
        params,
    )
    class_map = {"STD": 14, "SMA0": 14, "SUB": 15, "DBT": 16, "LOSS": 17}
    for asset_code, _count, princ_os, provision in class_rows:
        row = class_map.get(asset_code)
        if row:
            ws[f"C{row}"] = as_lakh(princ_os)
            ws[f"D{row}"] = as_lakh(provision)

    top_borrowers = rows(
        cur,
        latest_asset_cte()
        + """
        select
          row_number() over (order by la.ascd_princ_os desc) as sr_no,
          coalesce(nullif(a.gnlnac_cust_name, ''), to_char(la.ascd_account_num)) as borrower_name,
          'NA' as pan,
          'INDIVIDUAL' as borrower_type,
          coalesce(a.gnlnac_sanc_amt, 0) / 100000.0 as sanctioned_lakhs,
          coalesce(a.gnlnac_lndisb_amt, 0) / 100000.0 as disbursed_lakhs,
          (coalesce(a.gnlnac_sanc_amt, 0) - coalesce(a.gnlnac_lndisb_amt, 0)) / 100000.0 as undisbursed_lakhs,
          coalesce(la.ascd_princ_os, 0) / 100000.0 as principal_os_lakhs,
          coalesce(la.ascd_int_due, 0) / 100000.0 as interest_due_lakhs,
          case when la.ascd_asset_code in ('STD', 'SMA0') then 'Standard' else la.ascd_asset_code end as account_status,
          coalesce(la.ascd_princ_os + la.ascd_int_due + la.ascd_charg_due, 0) / 100000.0 as amount_os_lakhs
        from latest_asset la
        left join GICCPROD_NEW.genlnacnts a on a.gnlnac_acnt_num = la.ascd_account_num
        order by la.ascd_princ_os desc
        fetch first 25 rows only
        """,
        params,
    )
    write_rows(wb["DNBS02_Annex9"], 13, 2, top_borrowers, 25)

    npa_rows = rows(
        cur,
        latest_asset_cte()
        + """
        select
          row_number() over (order by la.ascd_princ_os desc) as sr_no,
          coalesce(nullif(a.gnlnac_cust_name, ''), to_char(la.ascd_account_num)) as borrower_name,
          'NA' as pan,
          'INDIVIDUAL' as borrower_type,
          'NA' as cin,
          coalesce(ap.genlnappl_ln_purpose, 'NA') as purpose,
          coalesce(a.gnlnac_princ_noi, 0) as duration,
          coalesce(a.gnlnac_loan_type, 'NA') as loan_type,
          coalesce(a.gnlnac_sanc_amt, 0) / 100000.0 as sanctioned_lakhs,
          coalesce(la.ascd_princ_os, 0) / 100000.0 as outstanding_lakhs,
          a.gnlnac_last_pymt_date,
          null as first_default_date,
          la.ascd_asset_code
        from latest_asset la
        left join GICCPROD_NEW.genlnacnts a on a.gnlnac_acnt_num = la.ascd_account_num
        left join GICCPROD_NEW.genlnappl ap on ap.genlnappl_lnacnt_no = la.ascd_account_num
        where la.ascd_asset_code not in ('STD', 'SMA0')
        order by la.ascd_princ_os desc
        fetch first 25 rows only
        """,
        params,
    )
    clear_range(wb["DNBS02_Annex11"], 13, 37, 2, 14)
    if npa_rows:
        write_rows(wb["DNBS02_Annex11"], 13, 2, npa_rows, 25)

    return metrics


def fill_gl_sections(wb, cur) -> dict[str, Decimal]:
    metrics = {
        "equity_share_capital_lakhs": gl_sum(cur, ["EQUITY SHARES"]),
        "share_premium_lakhs": gl_sum(cur, ["SHARES PREMIUM"]),
        "special_reserve_lakhs": gl_sum(cur, ["SPECIAL RESERVE"]),
        "general_reserve_lakhs": gl_sum(cur, ["GENERAL RESERVE"]),
        "bank_balances_lakhs": gl_sum(cur, ["BANK"], ["OD"]),
        "bank_od_lakhs": gl_sum(cur, ["OD"]),
        "investments_lakhs": gl_sum(cur, ["INVESTMENT"]),
        "fixed_assets_lakhs": gl_sum(cur, ["COMPUTER", "MOTOR", "SOFTWARE", "FURNITURE", "BUILDING", "PLANT"]),
    }
    ws = wb["DNBS02_PART1"]
    cell(ws, "C14", metrics["equity_share_capital_lakhs"])
    cell(ws, "C17", metrics["equity_share_capital_lakhs"])
    cell(ws, "C20", metrics["share_premium_lakhs"] + metrics["special_reserve_lakhs"] + metrics["general_reserve_lakhs"])
    cell(ws, "C23", metrics["share_premium_lakhs"])
    cell(ws, "C24", metrics["general_reserve_lakhs"])
    cell(ws, "C26", metrics["special_reserve_lakhs"])
    cell(ws, "C43", metrics["bank_od_lakhs"])

    ws = wb["DNBS02_PART2"]
    cell(ws, "C25", metrics["investments_lakhs"])
    cell(ws, "C28", gl_sum(cur, ["INVESTMENT IN SHARES"]))
    cell(ws, "C32", gl_sum(cur, ["MUTUAL FUND"]))
    cell(ws, "C44", metrics["bank_balances_lakhs"])
    cell(ws, "C46", metrics["bank_balances_lakhs"])
    cell(ws, "C60", metrics["fixed_assets_lakhs"])
    cell(ws, "C61", metrics["fixed_assets_lakhs"])
    return metrics


def fill_branches(wb, cur, params: dict[str, Any]) -> None:
    branch_rows = rows(
        cur,
        latest_asset_cte()
        + """
        select
          row_number() over (order by sum(la.ascd_princ_os) desc) as sr_no,
          'BRANCH ' || la.ascd_asset_cat as branch_name,
          'NA' as branch_address,
          'NA' as city,
          'NA' as state,
          'NA' as district,
          min(a.gnlnac_sanc_date) as opening_date,
          null as closing_date,
          0 as deposit_accounts,
          count(*) as loan_accounts,
          sum(la.ascd_princ_os) / 100000.0 as loans_os_lakhs,
          'Derived from asset_classify_dtls branch/category; no branch master found in GICCPROD_NEW.' as remarks
        from latest_asset la
        left join GICCPROD_NEW.genlnacnts a on a.gnlnac_acnt_num = la.ascd_account_num
        group by la.ascd_asset_cat
        order by sum(la.ascd_princ_os) desc
        """,
        params,
    )
    write_rows(wb["DNBS02_Annex13"], 13, 2, branch_rows, 25)


def add_validation_sheet(wb, cur, metrics: dict[str, Any], params: dict[str, Any]) -> None:
    if "Validation" in wb.sheetnames:
        del wb["Validation"]
    ws = wb.create_sheet("Validation")
    ws.append(["DNBS02 generation audit"])
    ws.append(["Period start", params["start_date"]])
    ws.append(["Period end", params["end_date"]])
    ws.append([])
    ws.append(["Metric", "Value"])
    for key, value in metrics.items():
        ws.append([key, value])
    ws.append([])
    ws.append(["Source table", "Rows in period/date used"])
    for table, date_col in [
        ("genlnacnts", "gnlnac_sanc_date"),
        ("genlndisb", "genlndisb_disb_date"),
        ("loanrepay", "lnrepay_repay_date"),
        ("asset_classify_dtls", "ascd_effective_date"),
        ("glbbal", "glbbal_year"),
    ]:
        if date_col == "glbbal_year":
            count = q1(cur, "select count(*) from GICCPROD_NEW.glbbal where glbbal_year = 2026")
        else:
            count = q1(
                cur,
                f'select count(*) from GICCPROD_NEW.{table.upper()} where {date_col.upper()} between :start_date and :end_date',
                params,
            )
        ws.append([f"GICCPROD_NEW.{table}", count])
    ws.append([])
    ws.append(["Not populated", "Reason"])
    for sheet, reason in [
        ("DNBS02_Annex1", "No ratings/instrument table found in bronze schema."),
        ("DNBS02_Annex2", "No shareholding table found in bronze schema."),
        ("DNBS02_Annex3", "Only firm contact table present; no full board/director master found."),
        ("DNBS02_Annex4-8", "No debenture/ICD/CP/subordinated debt subscriber tables found."),
        ("DNBS02_Annex10", "No investment transaction/detail table found; GL-only investment totals used in Part2."),
        ("DNBS02_Annex12", "No group company master table found."),
    ]:
        ws.append([sheet, reason])
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 90


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="2026-06-30")
    parser.add_argument("--out-dir", default="outputs")
    args = parser.parse_args()

    params = {"start_date": date.fromisoformat(args.start_date), "end_date": date.fromisoformat(args.end_date)}
    wb = load_workbook(args.template)
    fill_filing(wb, args.start_date, args.end_date)

    metrics: dict[str, Any] = {}
    with connect() as conn:
        with conn.cursor() as cur:
            metrics.update(fill_loan_sections(wb, cur, params))
            metrics.update(fill_gl_sections(wb, cur))
            fill_branches(wb, cur, params)
            add_validation_sheet(wb, cur, metrics, params)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"DNBS02_Report_20260401_to_20260630_generated.xlsx"
    wb.save(out)
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main()
