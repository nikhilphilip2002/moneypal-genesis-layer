from __future__ import annotations

import os
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None


def load_env() -> None:
    if load_dotenv:
        load_dotenv()
    info = Path("db_info.txt")
    if info.exists():
        for raw_line in info.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip().upper()
            value = value.split("#", 1)[0].strip().rstrip(",").strip('"').strip("'")
            aliases = {
                "HOST": "PGHOST",
                "PORT": "PGPORT",
                "DATABASE": "PGDATABASE",
                "DBNAME": "PGDATABASE",
                "USER": "PGUSER",
                "PASSWORD": "PGPASSWORD",
                "SCHEMA": "PGSCHEMA",
            }
            os.environ.setdefault(aliases.get(key, key), value)


def connect() -> Any:
    load_env()
    try:
        import psycopg
    except ImportError as exc:
        raise SystemExit(
            "Missing Postgres driver. Install dependencies with: pip install -r requirements.txt"
        ) from exc

    dsn = os.getenv("DATABASE_URL")
    if dsn:
        return psycopg.connect(dsn)

    required = ["PGHOST", "PGDATABASE", "PGUSER", "PGPASSWORD"]
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        raise SystemExit(
            "Missing DB credentials: "
            + ", ".join(missing)
            + ". Put them in .env or db_info.txt using .env.example."
        )

    return psycopg.connect(
        host=os.environ["PGHOST"],
        port=int(os.getenv("PGPORT", "5432")),
        dbname=os.environ["PGDATABASE"],
        user=os.environ["PGUSER"],
        password=os.environ["PGPASSWORD"],
    )


def bronze_schema() -> str:
    load_env()
    return os.getenv("PGSCHEMA", "bronze")
