from __future__ import annotations

import argparse
import json
from pathlib import Path

from openpyxl import load_workbook


def non_empty(values: list[object]) -> bool:
    return any(value not in (None, "") for value in values)


def sheet_spec(ws, max_data_rows: int) -> dict:
    header_row = None
    for row in range(1, min(ws.max_row, 25) + 1):
        labels = [ws.cell(row, col).value for col in range(2, ws.max_column + 1)]
        joined = " ".join(str(v).lower() for v in labels if v not in (None, ""))
        if any(token in joined for token in ["description", "amount", "sr. no", "particulars", "item"]):
            header_row = row
            break

    headers = []
    data_rows = []
    if header_row:
        for col in range(2, ws.max_column + 1):
            value = ws.cell(header_row, col).value
            if value not in (None, ""):
                headers.append({"column": col, "label": str(value).strip()})
        for row in range(header_row + 1, ws.max_row + 1):
            values = [ws.cell(row, col).value for col in range(2, ws.max_column + 1)]
            if non_empty(values):
                data_rows.append(
                    {
                        "row": row,
                        "label": "" if values[0] is None else str(values[0]).strip(),
                        "values": [
                            "" if value is None else str(value).strip()
                            for value in values[: len(headers)]
                        ],
                    }
                )
                if len(data_rows) >= max_data_rows:
                    break

    return {
        "title": ws.cell(2, 2).value,
        "max_row": ws.max_row,
        "max_column": ws.max_column,
        "header_row": header_row,
        "headers": headers,
        "data_rows": data_rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--out", default="config/dnbs02_template_spec.json")
    parser.add_argument("--max-data-rows", type=int, default=200)
    args = parser.parse_args()

    wb = load_workbook(args.template, data_only=True, read_only=True)
    spec = {
        "template": str(Path(args.template).resolve()),
        "sheets": {ws.title: sheet_spec(ws, args.max_data_rows) for ws in wb.worksheets},
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
