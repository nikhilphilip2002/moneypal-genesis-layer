from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="2026-06-30")
    parser.add_argument("--out-dir", default="outputs")
    args = parser.parse_args()

    # Reuse the Postgres workbook generator after swapping its DB facade.
    # The generated temporary module keeps the report logic in one place.
    source = Path("scripts/generate_dnbs02_auto_report.py").read_text(encoding="utf-8")
    oracle_source = source.replace("from db import connect", "from oracle_db import connect")
    oracle_source = oracle_source.replace("import argparse\n", "import argparse\nfrom datetime import date\n")
    oracle_source = oracle_source.replace(
        "cur.execute(sql, params or {})",
        "cur.execute(sql, {key: value for key, value in (params or {}).items() if key in sql})",
    )
    oracle_source = oracle_source.replace(
        'params = {"start_date": args.start_date, "end_date": args.end_date}',
        'params = {"start_date": date.fromisoformat(args.start_date), "end_date": date.fromisoformat(args.end_date)}',
    )
    oracle_source = oracle_source.replace("bronze.", "GICCPROD_NEW.")
    oracle_source = oracle_source.replace("la.ascd_account_num::text", "to_char(la.ascd_account_num)")
    oracle_source = oracle_source.replace("g.extgl_gl_head::text = b.glbbal_glacc_code", "to_char(g.extgl_gl_head) = b.glbbal_glacc_code")
    oracle_source = oracle_source.replace("limit 25", "fetch first 25 rows only")
    oracle_source = oracle_source.replace(" ilike ", " like ")
    oracle_source = oracle_source.replace(" not like ", " not like ")
    oracle_source = oracle_source.replace(
        'inc.append(f"coalesce(extgl_ext_head_descn, \'\') like %({key})s")',
        'inc.append(f"upper(coalesce(extgl_ext_head_descn, \'\')) like upper(:{key})")',
    )
    oracle_source = oracle_source.replace(
        'clauses.append(f"coalesce(extgl_ext_head_descn, \'\') not like %({key})s")',
        'clauses.append(f"upper(coalesce(extgl_ext_head_descn, \'\')) not like upper(:{key})")',
    )
    oracle_source = oracle_source.replace(
        'f\'select count(*) from GICCPROD_NEW."{table}" where "{date_col}" between :start_date and :end_date\'',
        "f'select count(*) from GICCPROD_NEW.{table.upper()} where {date_col.upper()} between :start_date and :end_date'",
    )
    oracle_source = oracle_source.replace(
        "f'select count(*) from GICCPROD_NEW.\"{table}\" where \"{date_col}\" between :start_date and :end_date'",
        "f'select count(*) from GICCPROD_NEW.{table.upper()} where {date_col.upper()} between :start_date and :end_date'",
    )
    oracle_source = oracle_source.replace("%(start_date)s", ":start_date")
    oracle_source = oracle_source.replace("%(end_date)s", ":end_date")
    oracle_source = oracle_source.replace(
        "f'select count(*) from GICCPROD_NEW.\"{table}\" where \"{date_col}\" between :start_date and :end_date'",
        "f'select count(*) from GICCPROD_NEW.{table.upper()} where {date_col.upper()} between :start_date and :end_date'",
    )
    oracle_source = oracle_source.replace("distinct on (ascd_account_num)", "")
    oracle_source = oracle_source.replace(
        """
    return \"""
    with latest_asset as (
      select 
        ascd_account_num,
        ascd_asset_cat,
        ascd_asset_code,
        ascd_dpd_days,
        ascd_princ_os,
        ascd_princ_due,
        ascd_int_due,
        ascd_charg_due,
        ascd_effective_date
      from GICCPROD_NEW.asset_classify_dtls
      where ascd_effective_date <= :end_date
      order by ascd_account_num, ascd_effective_date desc
    )
    \"""
""",
        """
    return \"""
    with latest_asset as (
      select
        ascd_account_num,
        ascd_asset_cat,
        ascd_asset_code,
        ascd_dpd_days,
        ascd_princ_os,
        ascd_princ_due,
        ascd_int_due,
        ascd_charg_due,
        ascd_effective_date
      from (
        select a.*,
          row_number() over (partition by ascd_account_num order by ascd_effective_date desc) rn
        from GICCPROD_NEW.asset_classify_dtls a
        where ascd_effective_date <= :end_date
      )
      where rn = 1
    )
    \"""
""",
    )
    tmp = Path("scripts/_generate_dnbs02_oracle_runtime.py")
    tmp.parent.mkdir(parents=True, exist_ok=True)
    tmp.write_text(oracle_source, encoding="utf-8")

    cmd = [
        sys.executable,
        str(tmp),
        "--template",
        args.template,
        "--start-date",
        args.start_date,
        "--end-date",
        args.end_date,
        "--out-dir",
        args.out_dir,
    ]
    subprocess.run(cmd, check=True)
    original = Path(args.out_dir) / "DNBS02_Report_20260401_to_20260630_generated.xlsx"
    renamed = Path(args.out_dir) / "DNBS02_Report_20260401_to_20260630_oracle.xlsx"
    if original.exists():
        original.replace(renamed)
        print(f"Wrote {renamed.resolve()}")


if __name__ == "__main__":
    main()
