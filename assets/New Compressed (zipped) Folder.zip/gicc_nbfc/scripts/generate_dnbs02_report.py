from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from db import connect


def load_mapping(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise SystemExit(f"Mapping file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")


def fill_scalar_queries(wb, conn, mapping: dict[str, Any], params: dict[str, Any]) -> None:
    for item in mapping.get("scalar_cells", []):
        sheet = item["sheet"]
        cell = item["cell"]
        sql = item["sql"]
        with conn.cursor() as cur:
            cur.execute(sql, params)
            row = cur.fetchone()
        wb[sheet][cell] = None if row is None else row[0]


def fill_table_queries(wb, conn, mapping: dict[str, Any], params: dict[str, Any]) -> None:
    for item in mapping.get("tables", []):
        ws = wb[item["sheet"]]
        start_row = int(item["start_row"])
        start_col = int(item.get("start_col", 2))
        max_rows = int(item.get("max_rows", 25))
        columns = item["columns"]
        with conn.cursor() as cur:
            cur.execute(item["sql"], params)
            rows = cur.fetchall()
        for offset in range(max_rows):
            for col_offset in range(len(columns)):
                ws.cell(start_row + offset, start_col + col_offset).value = None
        for row_offset, row in enumerate(rows[:max_rows]):
            for col_offset, value in enumerate(row[: len(columns)]):
                ws.cell(start_row + row_offset, start_col + col_offset).value = value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--mapping", default="config/dnbs02_mapping.json")
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="2026-06-30")
    parser.add_argument("--out-dir", default="outputs")
    args = parser.parse_args()

    template = Path(args.template)
    mapping = load_mapping(Path(args.mapping))
    params = {"start_date": args.start_date, "end_date": args.end_date}

    wb = load_workbook(template)
    with connect() as conn:
        fill_scalar_queries(wb, conn, mapping, params)
        fill_table_queries(wb, conn, mapping, params)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / safe_filename(f"DNBS02_Report_{args.start_date}_to_{args.end_date}.xlsx")
    wb.save(out)
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main()
