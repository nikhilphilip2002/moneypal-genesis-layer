from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from db import bronze_schema, connect


REPORT_KEYWORDS = {
    "sources_of_funds": ["capital", "share", "reserve", "borrowing", "debenture", "bank", "commercial paper"],
    "application_of_funds": ["loan", "advance", "investment", "asset", "cash", "bank", "receivable"],
    "profit_and_loss": ["income", "expense", "interest", "profit", "loss", "tax", "dividend"],
    "asset_classification": ["standard", "npa", "substandard", "doubtful", "loss", "provision"],
    "top_borrowers": ["borrower", "loan", "sanction", "disbursed", "principal", "outstanding"],
    "investments": ["investment", "equity", "preference", "debenture", "book value"],
    "branches": ["branch", "city", "state", "district", "opening"],
}


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def score_table(table: str, columns: list[str], keywords: list[str]) -> int:
    haystack = norm(table + " " + " ".join(columns))
    return sum(1 for keyword in keywords if norm(keyword) in haystack)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="2026-06-30")
    parser.add_argument("--out", default="outputs/bronze_discovery.json")
    args = parser.parse_args()

    schema = bronze_schema()
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                select table_name, column_name, data_type
                from information_schema.columns
                where table_schema = %s
                order by table_name, ordinal_position
                """,
                (schema,),
            )
            rows = cur.fetchall()

            tables: dict[str, list[dict[str, str]]] = {}
            for table, column, data_type in rows:
                tables.setdefault(table, []).append({"column": column, "type": data_type})

            profile = {}
            for table, cols in tables.items():
                date_cols = [
                    c["column"]
                    for c in cols
                    if c["type"] in ("date", "timestamp without time zone", "timestamp with time zone")
                    or "date" in c["column"].lower()
                ]
                numeric_cols = [
                    c["column"]
                    for c in cols
                    if c["type"] in ("numeric", "decimal", "double precision", "real", "integer", "bigint")
                ]
                row_count = None
                date_counts = {}
                cur.execute(f'select count(*) from "{schema}"."{table}"')
                row_count = cur.fetchone()[0]
                for date_col in date_cols[:5]:
                    try:
                        cur.execute(
                            f'''
                            select count(*)
                            from "{schema}"."{table}"
                            where "{date_col}"::date between %s and %s
                            ''',
                            (args.start_date, args.end_date),
                        )
                        date_counts[date_col] = cur.fetchone()[0]
                    except Exception:
                        conn.rollback()
                profile[table] = {
                    "columns": cols,
                    "row_count": row_count,
                    "date_columns": date_cols,
                    "numeric_columns": numeric_cols,
                    "rows_in_period_by_date_column": date_counts,
                }

    candidates = {}
    for section, keywords in REPORT_KEYWORDS.items():
        ranked = []
        for table, info in profile.items():
            table_score = score_table(table, [c["column"] for c in info["columns"]], keywords)
            if table_score:
                ranked.append(
                    {
                        "table": table,
                        "score": table_score,
                        "period_rows": max(info["rows_in_period_by_date_column"].values() or [0]),
                        "date_columns": info["date_columns"],
                        "numeric_columns": info["numeric_columns"][:20],
                    }
                )
        candidates[section] = sorted(ranked, key=lambda x: (x["score"], x["period_rows"]), reverse=True)[:10]

    output = {
        "schema": schema,
        "period": {"start": args.start_date, "end": args.end_date},
        "table_count": len(profile),
        "tables": profile,
        "report_candidates": candidates,
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
