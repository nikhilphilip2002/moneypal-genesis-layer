from __future__ import annotations

import argparse
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from oracle_db import connect


REPORT_DATE = date(2026, 6, 30)
START_DATE = date(2026, 4, 1)
END_DATE = date(2026, 6, 30)


def as_decimal(value: Any) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def q1(cur: Any, sql: str, params: dict[str, Any] | None = None) -> Any:
    cur.execute(sql, params or {})
    row = cur.fetchone()
    return None if row is None else row[0]


def qrow(cur: Any, sql: str, params: dict[str, Any] | None = None) -> tuple:
    cur.execute(sql, params or {})
    return cur.fetchone()


def qrows(cur: Any, sql: str, params: dict[str, Any] | None = None) -> list[tuple]:
    cur.execute(sql, params or {})
    return cur.fetchall()


def setv(ws, cell: str, value: Any) -> None:
    ws[cell] = value


def clear_rect(ws, min_row: int, max_row: int, min_col: int, max_col: int) -> None:
    for row in range(min_row, max_row + 1):
        for col in range(min_col, max_col + 1):
            ws.cell(row, col).value = None


def write_rows(ws, start_row: int, start_col: int, rows: list[tuple], max_rows: int) -> None:
    if rows:
        clear_rect(ws, start_row, start_row + max_rows - 1, start_col, start_col + len(rows[0]) - 1)
    for r_idx, row in enumerate(rows[:max_rows], start_row):
        for c_idx, value in enumerate(row, start_col):
            ws.cell(r_idx, c_idx).value = value


def round2(value: Any) -> float:
    return float(as_decimal(value).quantize(Decimal("0.01")))


def source_counts(cur: Any) -> dict[str, int]:
    rows = qrows(
        cur,
        """
        SELECT 'GENLNACNTS sanctioned in quarter', COUNT(*)
        FROM GICCPROD_NEW.GENLNACNTS
        WHERE GNLNAC_SANC_DATE BETWEEN :start_date AND :end_date
        UNION ALL
        SELECT 'GENLNDISB disbursed in quarter', COUNT(*)
        FROM GICCPROD_NEW.GENLNDISB
        WHERE GENLNDISB_DISB_DATE BETWEEN :start_date AND :end_date
        UNION ALL
        SELECT 'LOANREPAY repayments in quarter', COUNT(*)
        FROM GICCPROD_NEW.LOANREPAY
        WHERE LNREPAY_REPAY_DATE BETWEEN :start_date AND :end_date
        UNION ALL
        SELECT 'ASSET_CLASSIFY_DTLS in quarter', COUNT(*)
        FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS
        WHERE ASCD_EFFECTIVE_DATE BETWEEN :start_date AND :end_date
        UNION ALL
        SELECT 'GLBBAL year 2026', COUNT(*)
        FROM GICCPROD_NEW.GLBBAL
        WHERE GLBBAL_YEAR = 2026
        """,
        {"start_date": START_DATE, "end_date": END_DATE},
    )
    return {name: int(count) for name, count in rows}


def loan_report_metrics(cur: Any) -> dict[str, Decimal]:
    row = qrow(
        cur,
        """
        SELECT
            COUNT(*) AS account_count,
            SUM(GNLNR_PRINC_OS) / 100000 AS principal_os_lakhs,
            SUM(GNLNR_DISB_AMT) / 100000 AS disbursed_amount_lakhs,
            SUM(GNLNR_TOTAL_DUE) / 100000 AS total_due_lakhs,
            SUM(NVL(GNLNR_PRINC_DUE, 0)
              + NVL(GNLNR_INT_DUE, 0)
              + NVL(GNLNR_CHG_DUE, 0)
              + NVL(GNLNR_PENAL_DUE, 0)) / 100000 AS computed_due_lakhs
        FROM GICCPROD_NEW.GENLN_RPT_DAY
        WHERE GNLNR_REPORT_DATE = :report_date
        """,
        {"report_date": REPORT_DATE},
    )
    return {
        "account_count": as_decimal(row[0]),
        "principal_os_lakhs": as_decimal(row[1]),
        "disbursed_amount_lakhs": as_decimal(row[2]),
        "total_due_lakhs": as_decimal(row[3]),
        "computed_due_lakhs": as_decimal(row[4]),
    }


def asset_split_metrics(cur: Any) -> dict[str, Decimal]:
    rows = qrows(
        cur,
        """
        WITH latest_asset AS (
            SELECT *
            FROM (
                SELECT
                    a.*,
                    ROW_NUMBER() OVER (
                        PARTITION BY ASCD_ACCOUNT_NUM
                        ORDER BY ASCD_EFFECTIVE_DATE DESC
                    ) AS rn
                FROM GICCPROD_NEW.ASSET_CLASSIFY_DTLS a
                WHERE ASCD_EFFECTIVE_DATE <= :end_date
            )
            WHERE rn = 1
        )
        SELECT ASCD_ASSET_CAT, COUNT(*), SUM(ASCD_PRINC_OS) / 100000
        FROM latest_asset
        GROUP BY ASCD_ASSET_CAT
        """,
        {"end_date": END_DATE},
    )
    output = {"D_count": Decimal("0"), "D_lakhs": Decimal("0"), "U_count": Decimal("0"), "U_lakhs": Decimal("0")}
    for asset_cat, count, amount in rows:
        if asset_cat == "D":
            output["D_count"] = as_decimal(count)
            output["D_lakhs"] = as_decimal(amount)
        elif asset_cat == "U":
            output["U_count"] = as_decimal(count)
            output["U_lakhs"] = as_decimal(amount)
    return output


def flow_metrics(cur: Any) -> dict[str, Decimal]:
    sanctioned = q1(
        cur,
        """
        SELECT SUM(GNLNAC_SANC_AMT) / 100000
        FROM GICCPROD_NEW.GENLNACNTS
        WHERE GNLNAC_SANC_DATE BETWEEN :start_date AND :end_date
        """,
        {"start_date": START_DATE, "end_date": END_DATE},
    )
    disbursed = q1(
        cur,
        """
        SELECT SUM(GENLNDISB_DISB_AMT) / 100000
        FROM GICCPROD_NEW.GENLNDISB
        WHERE GENLNDISB_DISB_DATE BETWEEN :start_date AND :end_date
        """,
        {"start_date": START_DATE, "end_date": END_DATE},
    )
    principal_repaid, interest_repaid = qrow(
        cur,
        """
        SELECT SUM(LNREPAY_PRIN_AMT) / 100000,
               SUM(LNREPAY_INT_AMT) / 100000
        FROM GICCPROD_NEW.LOANREPAY
        WHERE LNREPAY_REPAY_DATE BETWEEN :start_date AND :end_date
        """,
        {"start_date": START_DATE, "end_date": END_DATE},
    )
    return {
        "sanctioned_lakhs": as_decimal(sanctioned),
        "disbursed_lakhs": as_decimal(disbursed),
        "principal_repaid_lakhs": as_decimal(principal_repaid),
        "interest_repaid_lakhs": as_decimal(interest_repaid),
    }


def gl_keyword_buckets(cur: Any) -> dict[str, Decimal]:
    rows = qrows(
        cur,
        """
        SELECT
            CASE
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%EQUITY SHARES%' THEN 'Equity Shares'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SHARES PREMIUM%' THEN 'Share Premium'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SPECIAL RESERVE%' THEN 'Special Reserve'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%GENERAL RESERVE%' THEN 'General Reserve'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BANK%' AND UPPER(g.EXTGL_EXT_HEAD_DESCN) NOT LIKE '%OD%' THEN 'Bank Balance/Deposit'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%OD%' THEN 'Bank OD'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%INVESTMENT%' THEN 'Investment'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%COMPUTER%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%MOTOR%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SOFTWARE%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%FURNITURE%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BUILDING%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%PLANT%' THEN 'Fixed Asset'
                ELSE 'Other'
            END AS dnbs_proxy_bucket,
            SUM(ABS(b.GLBBAL_BC_BAL)) / 100000 AS amount_lakhs
        FROM GICCPROD_NEW.GLBBAL b
        LEFT JOIN GICCPROD_NEW.EXTGL g
            ON TO_CHAR(g.EXTGL_GL_HEAD) = b.GLBBAL_GLACC_CODE
        WHERE b.GLBBAL_YEAR = 2026
        GROUP BY
            CASE
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%EQUITY SHARES%' THEN 'Equity Shares'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SHARES PREMIUM%' THEN 'Share Premium'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SPECIAL RESERVE%' THEN 'Special Reserve'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%GENERAL RESERVE%' THEN 'General Reserve'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BANK%' AND UPPER(g.EXTGL_EXT_HEAD_DESCN) NOT LIKE '%OD%' THEN 'Bank Balance/Deposit'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%OD%' THEN 'Bank OD'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%INVESTMENT%' THEN 'Investment'
                WHEN UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%COMPUTER%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%MOTOR%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%SOFTWARE%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%FURNITURE%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%BUILDING%'
                  OR UPPER(g.EXTGL_EXT_HEAD_DESCN) LIKE '%PLANT%' THEN 'Fixed Asset'
                ELSE 'Other'
            END
        """,
    )
    return {bucket: as_decimal(amount) for bucket, amount in rows}


def asset_code_summary(cur: Any) -> dict[str, tuple[Decimal, Decimal, Decimal]]:
    rows = qrows(
        cur,
        """
        SELECT
            NVL(GNLNR_ASSET_CD, 'NA') AS asset_code,
            COUNT(*) AS account_count,
            SUM(GNLNR_PRINC_OS) / 100000 AS principal_os_lakhs,
            SUM(NVL(GNLNR_PROVISION_AMT, 0)) / 100000 AS provision_lakhs
        FROM GICCPROD_NEW.GENLN_RPT_DAY
        WHERE GNLNR_REPORT_DATE = :report_date
        GROUP BY NVL(GNLNR_ASSET_CD, 'NA')
        """,
        {"report_date": REPORT_DATE},
    )
    return {code: (as_decimal(count), as_decimal(os), as_decimal(provision)) for code, count, os, provision in rows}


def top_borrowers(cur: Any) -> list[tuple]:
    return qrows(
        cur,
        """
        SELECT *
        FROM (
            SELECT
                ROW_NUMBER() OVER (
                    ORDER BY SUM(NVL(GNLNR_PRINC_OS, 0)
                               + NVL(GNLNR_INT_OS, 0)
                               + NVL(GNLNR_INT_DUE, 0)
                               + NVL(GNLNR_CHG_DUE, 0)
                               + NVL(GNLNR_PENAL_DUE, 0)) DESC
                ) AS sr_no,
                GNLNR_CUST_NAME AS borrower_name,
                NVL(GNLNR_PAN_NO, 'NA') AS pan,
                CASE SUBSTR(NVL(GNLNR_PAN_NO, 'NA'), 4, 1)
                    WHEN 'C' THEN 'CORPORATE'
                    WHEN 'F' THEN 'CORPORATE'
                    WHEN 'P' THEN 'INDIVIDUAL'
                    ELSE 'INDIVIDUAL'
                END AS borrower_type,
                ROUND(SUM(NVL(GNLNR_DISB_AMT, 0)) / 100000, 2) AS sanctioned_lakhs,
                ROUND(SUM(NVL(GNLNR_DISB_AMT, 0)) / 100000, 2) AS disbursed_lakhs,
                0 AS undisbursed_lakhs,
                ROUND(SUM(NVL(GNLNR_PRINC_OS, 0)) / 100000, 2) AS principal_os_lakhs,
                ROUND(SUM(NVL(GNLNR_INT_OS, 0) + NVL(GNLNR_INT_DUE, 0)) / 100000, 2) AS interest_os_lakhs,
                CASE
                    WHEN MAX(GNLNR_ASSET_CD) IN ('STD', 'SMA0', 'SMA1', 'SMA2') THEN 'Standard'
                    ELSE MAX(GNLNR_ASSET_CD)
                END AS status_of_account,
                ROUND(SUM(NVL(GNLNR_PRINC_OS, 0)
                        + NVL(GNLNR_INT_OS, 0)
                        + NVL(GNLNR_INT_DUE, 0)
                        + NVL(GNLNR_CHG_DUE, 0)
                        + NVL(GNLNR_PENAL_DUE, 0)) / 100000, 2) AS amount_outstanding_lakhs
            FROM GICCPROD_NEW.GENLN_RPT_DAY
            WHERE GNLNR_REPORT_DATE = :report_date
            GROUP BY GNLNR_CUST_NAME, NVL(GNLNR_PAN_NO, 'NA'), CASE SUBSTR(NVL(GNLNR_PAN_NO, 'NA'), 4, 1)
                    WHEN 'C' THEN 'CORPORATE'
                    WHEN 'F' THEN 'CORPORATE'
                    WHEN 'P' THEN 'INDIVIDUAL'
                    ELSE 'INDIVIDUAL'
                END
        )
        WHERE sr_no <= 25
        ORDER BY sr_no
        """,
        {"report_date": REPORT_DATE},
    )


def fill_report(wb, metrics: dict[str, Any]) -> None:
    loan = metrics["loan"]
    split = metrics["split"]
    flow = metrics["flow"]
    gl = metrics["gl"]
    asset = metrics["asset"]

    filing = wb["FilingInfo"]
    setv(filing, "C12", "01/04/2026")
    setv(filing, "C13", "30/06/2026")
    setv(filing, "C14", "INR")
    setv(filing, "C15", "ACTUALS")
    setv(filing, "C19", "Un-Audited")

    part1 = wb["DNBS02_PART1"]
    equity = gl.get("Equity Shares", Decimal("0"))
    share_premium = gl.get("Share Premium", Decimal("0"))
    general_reserve = gl.get("General Reserve", Decimal("0"))
    special_reserve = gl.get("Special Reserve", Decimal("0"))
    bank_od = gl.get("Bank OD", Decimal("0"))
    setv(part1, "C13", round2(equity))
    setv(part1, "C14", round2(equity))
    setv(part1, "C20", round2(share_premium + general_reserve + special_reserve))
    setv(part1, "C23", round2(share_premium))
    setv(part1, "C24", round2(general_reserve))
    setv(part1, "C25", round2(special_reserve))
    setv(part1, "C31", round2(bank_od))
    setv(part1, "C41", round2(bank_od))
    setv(part1, "C45", round2(bank_od))
    setv(part1, "C88", round2(bank_od))

    part2 = wb["DNBS02_PART2"]
    loans_total = loan["principal_os_lakhs"]
    setv(part2, "C13", round2(loans_total))
    setv(part2, "C14", round2(split["D_lakhs"]))
    setv(part2, "C15", round2(split["U_lakhs"]))
    setv(part2, "C17", round2(loans_total))
    setv(part2, "C19", round2(loans_total))
    setv(part2, "C23", round2(loans_total))
    setv(part2, "C25", round2(gl.get("Investment", Decimal("0"))))
    setv(part2, "C44", round2(gl.get("Bank Balance/Deposit", Decimal("0"))))
    setv(part2, "C46", round2(gl.get("Bank Balance/Deposit", Decimal("0"))))
    setv(part2, "C60", round2(gl.get("Fixed Asset", Decimal("0"))))
    setv(part2, "C61", round2(gl.get("Fixed Asset", Decimal("0"))))
    setv(part2, "C67", round2(loans_total + gl.get("Investment", Decimal("0")) + gl.get("Bank Balance/Deposit", Decimal("0")) + gl.get("Fixed Asset", Decimal("0"))))
    setv(part2, "C69", round2(loans_total + gl.get("Investment", Decimal("0"))))

    part3 = wb["DNBS02_PART3"]
    interest = flow["interest_repaid_lakhs"]
    setv(part3, "C13", round2(interest))
    setv(part3, "D13", round2(interest))
    setv(part3, "C14", round2(interest))
    setv(part3, "D14", round2(interest))
    setv(part3, "C20", round2(interest))
    setv(part3, "D20", round2(interest))
    setv(part3, "C22", round2(interest))
    setv(part3, "D22", round2(interest))
    setv(part3, "C32", round2(interest))
    setv(part3, "D32", round2(interest))
    setv(part3, "C53", round2(interest))
    setv(part3, "D53", round2(interest))

    part4 = wb["DNBS02_PART4"]
    owned_fund = share_premium + general_reserve + special_reserve + equity
    setv(part4, "C13", round2(owned_fund))
    setv(part4, "C20", round2(owned_fund))
    setv(part4, "C30", round2(owned_fund))

    part8 = wb["DNBS02_PART8"]
    std_count = sum(asset.get(code, (Decimal("0"), Decimal("0"), Decimal("0")))[0] for code in ["STD", "SMA0", "SMA1", "SMA2", "NA"])
    std_os = sum(asset.get(code, (Decimal("0"), Decimal("0"), Decimal("0")))[1] for code in ["STD", "SMA0", "SMA1", "SMA2", "NA"])
    for row in [14, 16]:
        setv(part8, f"C{row}", int(loan["account_count"]))
        setv(part8, f"D{row}", round2(loans_total))
        setv(part8, f"S{row}", int(std_count))
        setv(part8, f"T{row}", round2(std_os))

    part8c = wb["DNBS02_PART8C"]
    setv(part8c, "C15", round2(std_os))
    setv(part8c, "D15", round2(sum(asset.get(code, (Decimal("0"), Decimal("0"), Decimal("0")))[2] for code in ["STD", "SMA0", "SMA1", "SMA2", "NA"])))
    setv(part8c, "C19", round2(loans_total))
    setv(part8c, "D19", round2(sum(value[2] for value in asset.values())))
    setv(part8c, "C24", round2(loans_total))

    write_rows(wb["DNBS02_Annex9"], 13, 2, metrics["top_borrowers"], 25)


def add_audit_sheet(wb, metrics: dict[str, Any]) -> None:
    if "SQL_Source_Audit" in wb.sheetnames:
        del wb["SQL_Source_Audit"]
    ws = wb.create_sheet("SQL_Source_Audit")
    ws.append(["Report generated from Oracle validation queries"])
    ws.append(["Schema", "GICCPROD_NEW"])
    ws.append(["Period", "2026-04-01 to 2026-06-30"])
    ws.append(["Quarter end", "2026-06-30"])
    ws.append([])
    ws.append(["Metric", "Value"])
    for name, count in metrics["counts"].items():
        ws.append([name, count])
    for group_name in ["loan", "split", "flow", "gl"]:
        ws.append([])
        ws.append([group_name, ""])
        for key, value in metrics[group_name].items():
            ws.append([key, value])
    ws.append([])
    ws.append(["Source query families"])
    ws.append(["PART1/PART2 GL", "GLBBAL joined to EXTGL; keyword proxy buckets"])
    ws.append(["PART2 loan total", "GENLN_RPT_DAY where GNLNR_REPORT_DATE = DATE '2026-06-30'"])
    ws.append(["PART2 secured/unsecured", "Latest ASSET_CLASSIFY_DTLS up to DATE '2026-06-30'"])
    ws.append(["PART3 interest", "LOANREPAY where LNREPAY_REPAY_DATE between quarter dates"])
    ws.append(["PART8/PART8C", "GENLN_RPT_DAY grouped by GNLNR_ASSET_CD"])
    ws.append(["Annex9", "GENLN_RPT_DAY aggregated by GNLNR_CUST_NAME and GNLNR_PAN_NO"])
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 95


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--template", required=True)
    parser.add_argument("--out", default="outputs/DNBS02_Report_20260401_to_20260630_oracle_sql_generated.xlsx")
    args = parser.parse_args()

    wb = load_workbook(args.template)
    with connect() as conn:
        with conn.cursor() as cur:
            metrics = {
                "counts": source_counts(cur),
                "loan": loan_report_metrics(cur),
                "split": asset_split_metrics(cur),
                "flow": flow_metrics(cur),
                "gl": gl_keyword_buckets(cur),
                "asset": asset_code_summary(cur),
                "top_borrowers": top_borrowers(cur),
            }

    fill_report(wb, metrics)
    add_audit_sheet(wb, metrics)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main()
