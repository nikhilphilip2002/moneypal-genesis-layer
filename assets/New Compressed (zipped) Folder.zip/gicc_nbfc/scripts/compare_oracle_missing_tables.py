from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from oracle_db import connect


MISSING_REQUIREMENTS = {
    "DNBS02_Annex1_Rating_Sheet": {
        "table_keywords": ["rating", "instrument", "agency", "rated"],
        "column_keywords": [
            "instrument",
            "rating",
            "agency",
            "amount",
            "expiry",
            "previous",
        ],
    },
    "DNBS02_Annex2_Shareholding": {
        "table_keywords": ["share", "shareholder", "capital"],
        "column_keywords": ["shareholder", "capital", "pan", "share", "face", "percent"],
    },
    "DNBS02_Annex3_Board_Directors": {
        "table_keywords": ["director", "board", "din", "kmp"],
        "column_keywords": ["director", "appointment", "din", "pan", "contact", "email"],
    },
    "DNBS02_Annex4_Secured_Debentures": {
        "table_keywords": ["debenture", "secured", "subscriber", "ncd"],
        "column_keywords": ["subscriber", "pan", "issued", "rating", "maturity", "coupon", "outstanding"],
    },
    "DNBS02_Annex5_ICD_Placed": {
        "table_keywords": ["icd", "inter corporate", "deposit", "corporate"],
        "column_keywords": ["corporate", "cin", "pan", "amount", "deposit", "maturity", "outstanding", "group"],
    },
    "DNBS02_Annex6_Commercial_Paper": {
        "table_keywords": ["commercial paper", "cp", "subscriber"],
        "column_keywords": ["subscriber", "pan", "issued", "face", "rating", "maturity", "discount", "outstanding"],
    },
    "DNBS02_Annex7_Unsecured_Debentures": {
        "table_keywords": ["debenture", "unsecured", "subscriber", "ncd"],
        "column_keywords": ["subscriber", "pan", "issued", "rating", "maturity", "coupon", "outstanding"],
    },
    "DNBS02_Annex8_Subordinated_Debt": {
        "table_keywords": ["subordinated", "debt", "subscriber"],
        "column_keywords": ["subscriber", "pan", "issued", "rating", "maturity", "coupon", "outstanding"],
    },
    "DNBS02_Annex10_Investments": {
        "table_keywords": ["investment", "invest", "equity", "preference", "debenture"],
        "column_keywords": ["entity", "investment", "type", "pan", "book", "group", "outstanding"],
    },
    "DNBS02_Annex12_Group_Companies": {
        "table_keywords": ["group", "associate", "subsidiary", "related"],
        "column_keywords": ["company", "pan", "relationship", "rbi", "nbfc", "asset"],
    },
    "DNBS02_Annex13_Branch_Master": {
        "table_keywords": ["branch", "brn"],
        "column_keywords": ["branch", "address", "city", "state", "district", "opening", "closing"],
    },
    "GL_to_DNBS02_Mapping": {
        "table_keywords": ["dnbs", "rbi", "report", "mapping", "gl"],
        "column_keywords": ["gl", "description", "sheet", "row", "cell", "sign", "remarks"],
    },
}

SYSTEM_OWNERS = {
    "SYS",
    "SYSTEM",
    "XDB",
    "CTXSYS",
    "MDSYS",
    "ORDSYS",
    "OUTLN",
    "WMSYS",
    "DBSNMP",
    "GSMADMIN_INTERNAL",
    "LBACSYS",
    "OJVMSYS",
    "DVSYS",
    "AUDSYS",
}


def norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def keyword_score(haystack: str, keywords: list[str]) -> int:
    normalized = norm(haystack)
    score = 0
    for keyword in keywords:
        key = norm(keyword)
        if key and key in normalized:
            score += 1
    return score


def get_metadata() -> dict[str, dict]:
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                select owner, table_name, num_rows
                from all_tables
                where owner not in ({})
                order by owner, table_name
                """.format(",".join([f"'{owner}'" for owner in sorted(SYSTEM_OWNERS)]))
            )
            tables = {
                f"{owner}.{table_name}": {
                    "owner": owner,
                    "table": table_name,
                    "num_rows": num_rows,
                    "columns": [],
                }
                for owner, table_name, num_rows in cur.fetchall()
            }

            cur.execute(
                """
                select owner, table_name, column_name, data_type
                from all_tab_columns
                where owner not in ({})
                order by owner, table_name, column_id
                """.format(",".join([f"'{owner}'" for owner in sorted(SYSTEM_OWNERS)]))
            )
            for owner, table_name, column_name, data_type in cur.fetchall():
                key = f"{owner}.{table_name}"
                if key in tables:
                    tables[key]["columns"].append(
                        {"column": column_name, "type": data_type}
                    )
    return tables


def compare(tables: dict[str, dict]) -> dict[str, list[dict]]:
    results: dict[str, list[dict]] = {}
    for req_name, req in MISSING_REQUIREMENTS.items():
        candidates = []
        for full_name, info in tables.items():
            column_names = [col["column"] for col in info["columns"]]
            table_score = keyword_score(full_name, req["table_keywords"])
            column_score = keyword_score(" ".join(column_names), req["column_keywords"])
            score = table_score * 3 + column_score
            if score:
                candidates.append(
                    {
                        "owner": info["owner"],
                        "table": info["table"],
                        "full_name": full_name,
                        "score": score,
                        "table_keyword_hits": table_score,
                        "column_keyword_hits": column_score,
                        "num_rows": info["num_rows"],
                        "matching_columns": [
                            col
                            for col in column_names
                            if keyword_score(col, req["column_keywords"])
                        ][:30],
                        "all_columns": column_names,
                    }
                )
        results[req_name] = sorted(
            candidates,
            key=lambda row: (row["score"], row["num_rows"] or 0),
            reverse=True,
        )[:15]
    return results


def write_text_report(path: Path, results: dict[str, list[dict]]) -> None:
    lines = ["Oracle comparison for missing DNBS02 source tables", "=" * 55, ""]
    for req_name, candidates in results.items():
        lines.append(req_name)
        lines.append("-" * len(req_name))
        if not candidates:
            lines.append("No likely table found.")
        else:
            for idx, candidate in enumerate(candidates[:8], 1):
                lines.append(
                    f"{idx}. {candidate['full_name']} | score={candidate['score']} | rows={candidate['num_rows']}"
                )
                lines.append(
                    "   matching columns: "
                    + (", ".join(candidate["matching_columns"]) or "none")
                )
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json-out", default="outputs/oracle_missing_table_comparison.json")
    parser.add_argument("--txt-out", default="outputs/oracle_missing_table_comparison.txt")
    args = parser.parse_args()

    tables = get_metadata()
    results = compare(tables)

    json_out = Path(args.json_out)
    txt_out = Path(args.txt_out)
    json_out.parent.mkdir(parents=True, exist_ok=True)
    txt_out.parent.mkdir(parents=True, exist_ok=True)
    json_out.write_text(
        json.dumps(
            {
                "oracle_table_count": len(tables),
                "requirements": MISSING_REQUIREMENTS,
                "results": results,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )
    write_text_report(txt_out, results)
    print(f"Wrote {json_out}")
    print(f"Wrote {txt_out}")


if __name__ == "__main__":
    main()
