from __future__ import annotations

import argparse
import csv
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from db import connect as connect_pg
from oracle_db import connect as connect_oracle


LAKH = Decimal("100000")


METRICS = [
    {
        "name": "loan_outstanding_lakhs",
        "pg_sql": """
            with latest_asset as (
              select distinct on (ascd_account_num) ascd_account_num, ascd_princ_os, ascd_effective_date
              from bronze.asset_classify_dtls
              where ascd_effective_date <= %(end_date)s
              order by ascd_account_num, ascd_effective_date desc
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset
        """,
        "ora_sql": """
            with latest_asset as (
              select ascd_account_num, ascd_princ_os, ascd_effective_date
              from (
                select a.*,
                  row_number() over (partition by ascd_account_num order by ascd_effective_date desc) rn
                from GICCPROD_NEW.asset_classify_dtls a
                where ascd_effective_date <= :end_date
              )
              where rn = 1
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset
        """,
    },
    {
        "name": "secured_outstanding_lakhs",
        "pg_sql": """
            with latest_asset as (
              select distinct on (ascd_account_num) ascd_account_num, ascd_asset_cat, ascd_princ_os, ascd_effective_date
              from bronze.asset_classify_dtls
              where ascd_effective_date <= %(end_date)s
              order by ascd_account_num, ascd_effective_date desc
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset where ascd_asset_cat = 'D'
        """,
        "ora_sql": """
            with latest_asset as (
              select ascd_account_num, ascd_asset_cat, ascd_princ_os, ascd_effective_date
              from (
                select a.*,
                  row_number() over (partition by ascd_account_num order by ascd_effective_date desc) rn
                from GICCPROD_NEW.asset_classify_dtls a
                where ascd_effective_date <= :end_date
              )
              where rn = 1
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset where ascd_asset_cat = 'D'
        """,
    },
    {
        "name": "unsecured_outstanding_lakhs",
        "pg_sql": """
            with latest_asset as (
              select distinct on (ascd_account_num) ascd_account_num, ascd_asset_cat, ascd_princ_os, ascd_effective_date
              from bronze.asset_classify_dtls
              where ascd_effective_date <= %(end_date)s
              order by ascd_account_num, ascd_effective_date desc
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset where ascd_asset_cat = 'U'
        """,
        "ora_sql": """
            with latest_asset as (
              select ascd_account_num, ascd_asset_cat, ascd_princ_os, ascd_effective_date
              from (
                select a.*,
                  row_number() over (partition by ascd_account_num order by ascd_effective_date desc) rn
                from GICCPROD_NEW.asset_classify_dtls a
                where ascd_effective_date <= :end_date
              )
              where rn = 1
            )
            select sum(ascd_princ_os) / 100000.0 from latest_asset where ascd_asset_cat = 'U'
        """,
    },
    {
        "name": "sanctioned_qtr_lakhs",
        "pg_sql": "select sum(gnlnac_sanc_amt) / 100000.0 from bronze.genlnacnts where gnlnac_sanc_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select sum(gnlnac_sanc_amt) / 100000.0 from GICCPROD_NEW.genlnacnts where gnlnac_sanc_date between :start_date and :end_date",
    },
    {
        "name": "disbursed_qtr_lakhs",
        "pg_sql": "select sum(genlndisb_disb_amt) / 100000.0 from bronze.genlndisb where genlndisb_disb_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select sum(genlndisb_disb_amt) / 100000.0 from GICCPROD_NEW.genlndisb where genlndisb_disb_date between :start_date and :end_date",
    },
    {
        "name": "principal_repaid_qtr_lakhs",
        "pg_sql": "select sum(lnrepay_prin_amt) / 100000.0 from bronze.loanrepay where lnrepay_repay_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select sum(lnrepay_prin_amt) / 100000.0 from GICCPROD_NEW.loanrepay where lnrepay_repay_date between :start_date and :end_date",
    },
    {
        "name": "interest_repaid_qtr_lakhs",
        "pg_sql": "select sum(lnrepay_int_amt) / 100000.0 from bronze.loanrepay where lnrepay_repay_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select sum(lnrepay_int_amt) / 100000.0 from GICCPROD_NEW.loanrepay where lnrepay_repay_date between :start_date and :end_date",
    },
    {
        "name": "asset_classify_rows_in_period",
        "pg_sql": "select count(*) from bronze.asset_classify_dtls where ascd_effective_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select count(*) from GICCPROD_NEW.asset_classify_dtls where ascd_effective_date between :start_date and :end_date",
    },
    {
        "name": "loan_account_rows_in_period",
        "pg_sql": "select count(*) from bronze.genlnacnts where gnlnac_sanc_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select count(*) from GICCPROD_NEW.genlnacnts where gnlnac_sanc_date between :start_date and :end_date",
    },
    {
        "name": "disbursement_rows_in_period",
        "pg_sql": "select count(*) from bronze.genlndisb where genlndisb_disb_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select count(*) from GICCPROD_NEW.genlndisb where genlndisb_disb_date between :start_date and :end_date",
    },
    {
        "name": "repayment_rows_in_period",
        "pg_sql": "select count(*) from bronze.loanrepay where lnrepay_repay_date between %(start_date)s and %(end_date)s",
        "ora_sql": "select count(*) from GICCPROD_NEW.loanrepay where lnrepay_repay_date between :start_date and :end_date",
    },
    {
        "name": "gl_balance_rows_2026",
        "pg_sql": "select count(*) from bronze.glbbal where glbbal_year = 2026",
        "ora_sql": "select count(*) from GICCPROD_NEW.glbbal where glbbal_year = 2026",
    },
]


def one(cur: Any, sql: str, params: dict[str, Any]) -> Decimal:
    used_params = {key: value for key, value in params.items() if key in sql}
    cur.execute(sql, used_params)
    value = cur.fetchone()[0]
    return Decimal("0") if value is None else Decimal(str(value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="2026-06-30")
    parser.add_argument("--out", default="outputs/postgres_oracle_metric_comparison.csv")
    args = parser.parse_args()
    params = {
        "start_date": date.fromisoformat(args.start_date),
        "end_date": date.fromisoformat(args.end_date),
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    with connect_pg() as pg_conn, connect_oracle() as ora_conn:
        with pg_conn.cursor() as pg_cur, ora_conn.cursor() as ora_cur:
            output_rows = []
            for metric in METRICS:
                pg_value = one(pg_cur, metric["pg_sql"], params)
                ora_value = one(ora_cur, metric["ora_sql"], params)
                diff = pg_value - ora_value
                output_rows.append(
                    {
                        "metric": metric["name"],
                        "postgres_value": pg_value,
                        "oracle_value": ora_value,
                        "difference_pg_minus_oracle": diff,
                        "status": "MATCH" if abs(diff) < Decimal("0.0001") else "MISMATCH",
                    }
                )

    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "metric",
                "postgres_value",
                "oracle_value",
                "difference_pg_minus_oracle",
                "status",
            ],
        )
        writer.writeheader()
        writer.writerows(output_rows)
    print(f"Wrote {out.resolve()}")


if __name__ == "__main__":
    main()
